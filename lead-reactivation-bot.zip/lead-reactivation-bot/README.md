# Lead Reactivation Bot

SMS + AI chatbot system that contacts a company's old/dormant leads, re-engages
them via text, and hands off "hot" replies to the sales team. Built to track
closed deals so you can calculate your commission automatically.

## How it works

1. **Import** — the company exports their old leads to CSV; you load them in.
2. **First touch** — an automated SMS goes out to each lead asking if they're
   still interested.
3. **Follow-ups** — non-responders get up to 2 more nudges over the following
   days, then get marked "cold."
4. **AI conversation** — any reply is picked up by Claude, which classifies
   intent (interested / not interested / needs info / opted out) and drafts
   a natural, on-brand SMS reply.
5. **Hot lead alert** — when someone shows real interest, it's logged (wire
   `notifyHotLead()` in `server.js` to Slack/email/webhook to alert the
   company's closer in real time).
6. **Deal tracking** — once the company confirms a close, you record the deal
   value and your commission is calculated automatically.

## Setup

### 1. Prerequisites
- Node.js 18+
- A [Twilio](https://twilio.com) account with a phone number capable of SMS
- An [Anthropic API key](https://console.anthropic.com)
- A public URL for Twilio to reach your server (use [ngrok](https://ngrok.com)
  for local testing, or deploy to Render/Railway/a VPS for production)

### 2. Install
```bash
npm install
cp .env.example .env
# then fill in .env with your real credentials
```

### 3. Configure Twilio webhook
In the Twilio console, under your phone number's messaging settings, set
"A MESSAGE COMES IN" to:
```
https://your-public-url/webhooks/sms
```

### 4. Import a company's leads
Prepare a CSV with columns: `name, phone, email, original_interest, last_contact_date`
```bash
node scripts/import-leads.js path/to/leads.csv
```

### 5. Start the server
```bash
npm start
```

### 6. Send the first batch
```bash
node scripts/send-initial-batch.js 50
```
This sends to 50 leads at a time — run it daily (or on a cron) to work
through a large list gradually.

### 7. Run follow-ups daily
```bash
node scripts/send-followups.js
```
Set this up as a daily cron job (or use `node-cron` inside `server.js` if
you want it self-contained in one process).

### 8. When a deal closes
```bash
curl -X POST http://localhost:3000/api/deals/close \
  -H "Content-Type: application/json" \
  -d '{"phone": "+15551234567", "deal_value": 8000, "commission_rate": 0.5}'
```

### 9. Check your commission summary
```bash
curl http://localhost:3000/api/summary
```

## ⚠️ Compliance — read before sending anything

Texting old leads carries real legal risk, and this is worth getting right
before you send a single message:

- **TCPA (US)** and equivalent rules elsewhere require the company to have
  valid consent on file for these specific leads to receive SMS marketing —
  "they were a lead once" is not automatically consent to text them again,
  especially if time has passed. **Get written confirmation from each company
  that their leads consented to SMS marketing before you import their list.**
- **STOP handling is mandatory** — this system honors STOP replies
  automatically and immediately opts the lead out. Never remove this.
- **Quiet hours** — most jurisdictions restrict marketing texts to roughly
  8am–9pm local time. This prototype doesn't currently check the lead's
  timezone before sending; add that check before scaling up.
- **Identify the sender** — messages should make clear who's texting (the
  company name is included in the templates).
- **Get this in writing with each company** — your 50% commission arrangement
  and who's liable for consent/compliance should be a written agreement, not
  a handshake deal. Worth having a simple contract template before you take
  on leads from a second company.

None of this is legal advice — if you're planning to run this across
multiple companies/industries, it's worth a quick call with a lawyer
familiar with SMS marketing compliance in whatever countries your companies
operate in.

## Files

```
├── server.js              # Express server: Twilio webhook + API endpoints
├── db.js                  # SQLite schema and data access functions
├── chatbot.js             # Claude-powered reply classification + drafting
├── scripts/
│   ├── import-leads.js       # CSV → database
│   ├── send-initial-batch.js # First-touch SMS sender
│   └── send-followups.js     # Drip follow-up sequence
├── .env.example            # Credentials template
└── package.json
```

## Extending this

- **Dashboard UI**: the `/api/leads/:status` and `/api/summary` endpoints are
  ready to plug into a simple frontend if you want a visual pipeline view.
- **Multi-company support**: right now this assumes one company/campaign per
  deployment. To run this for multiple companies, add a `company_id` column
  to the `leads` table and scope queries by it.
- **Email fallback**: if a lead has no valid phone but has an email, you could
  add an email-based reactivation flow alongside SMS.
